import React from 'react';


// import { Container } from './styles';

function Home() {

    return (
        <React.Fragment>
            <main>
                <div className="container-fluid">
                    <div className="jumbotron bg-ligth">
                        <h2 className="mb-4">Seja bem vindo(a)!</h2>
                        <p>Aqui nessa loja, <strong>programadores tem desconto</strong> nos produtos para sua casa!</p>
                    </div>
                </div>
                <hr />
            </main>

            <br /><br /><br /><br />
            <br /><br /><br /><br />
            
            <hr />
        </React.Fragment>
    )
}

export default Home;