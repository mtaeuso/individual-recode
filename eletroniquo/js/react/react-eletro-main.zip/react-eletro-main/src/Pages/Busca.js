// import { useEffect, useState } from 'react';
import  Form  from "react-bootstrap";
import Infos from './Infos';

//export default function Busca(props) {
 //   const [ busca, setBusca ] = useState("");

   // const quandoDigitado = (evento) => {
     //   const valor = evento.target.value;
       // console.log(valor);

    //}
    //]
//}